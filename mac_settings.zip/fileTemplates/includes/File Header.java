#set ($USER = "Sudipta K Paik")
#set ($EMAIL = "sudipta@w3engineers.com")
#set ($COMPANY = "W3 Engineers Ltd")
 
/**
* * ============================================================================
* * Copyright (C) ${YEAR} ${COMPANY} - All Rights Reserved.
* * Unauthorized copying of this file, via any medium is strictly prohibited
* * Proprietary and confidential
* * ----------------------------------------------------------------------------
* * Created by: ${USER} on [${DAY}-${MONTH_NAME_SHORT}-${YEAR} at ${TIME}].
* * Email: ${EMAIL}
* * ----------------------------------------------------------------------------
* * Project: ${PROJECT_NAME}.
* * Code Responsibility: <Purpose of code>
* * ----------------------------------------------------------------------------
* * Edited by : 
* * --> <First Editor> on [${DAY}-${MONTH_NAME_SHORT}-${YEAR} at ${TIME}].
* * --> <Second Editor> on [${DAY}-${MONTH_NAME_SHORT}-${YEAR} at ${TIME}].
* * ----------------------------------------------------------------------------
* * Reviewed by : 
* * --> <First Reviewer> on [${DAY}-${MONTH_NAME_SHORT}-${YEAR} at ${TIME}].
* * --> <Second Reviewer> on [${DAY}-${MONTH_NAME_SHORT}-${YEAR} at ${TIME}].
* * ============================================================================
**/

